package MockInterviewPractice;

import java.util.*;
public class Out {
	
	public static void addNumber(List<? super Integer> list) {
		for(int i=1;i<=10;i++) {
			list.add(i);
		}
		
	}

	public static void main(String[] args) {
		List<Double> ld = Arrays.asList(null);
		//addNumber(10.4);;
		

	}

}
