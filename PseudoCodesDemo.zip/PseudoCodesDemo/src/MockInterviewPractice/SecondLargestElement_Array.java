package MockInterviewPractice;

import java.util.Scanner;

public class SecondLargestElement_Array {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Array Size : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		System.out.println("Enter the Array Elements : ");
		
		for(int i=0;i<arr.length;i++) {
			arr[i] = sc.nextInt();
		}
		
		int max= arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>max)
				max= arr[i];
		}
		System.out.println("The Largest element in an Array is :" + max);
		
		int second_max = arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>second_max & arr[i] != max)
				second_max=arr[i];
		}
		System.out.println("The second largest element in an array is : "+second_max);
		
		
	}
	
    
	

}
