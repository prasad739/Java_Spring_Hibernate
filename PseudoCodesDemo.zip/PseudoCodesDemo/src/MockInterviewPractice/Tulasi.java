package MockInterviewPractice;

import java.util.ArrayList;
import java.util.HashMap;

public class Tulasi {
	

	public static void main(String[] args) {
		
//		String text = "hiheyhello";
//		int index = text.lastIndexOf("h",4);
//		System.out.println(index);
		
//		Map<String,String> map = new LinkedHashMap<>();
//		map.put("john", "Engineer");
//		map.put("jane", "Teacher");
//		map.put("john", "Doctor");
//		System.out.println(map);
		
//		Main type = new Main();
//		type.send("Pankaj");
//		String str = (string) type.receive();
//		System.out.println(str);
//	}
//	public Object receive() {
//		return data;
//	}
//	public void send(Object data) {
//		this.data = data;
//	}
		
//		HashMap<Integer , ArrayList<Integer>> map = new HashMap<>();
//		ArrayList<Integer> arrayList = new ArrayList<>();
//		arrayList.add(null);
//		arrayList.add(null);
//		map.put(1, null);
//		map.put(2, arrayList);
//		System.out.println(map);
		String[] arr = new String[10];
		arr[0] = "5001";
		arr[1] = "5002";
		arr = new String[] {"1001", "1002","1003"};
		StringBuilder sum = new StringBuilder();
		for(String s:arr) {
			sum.append(s);
			
		}
		System.out.println(sum);
		
		
		
		
		
		
		
	}
		
		
		
		
		
		

	

}
