package MockInterviewPractice;

import java.util.Stack;

public class Generic <E>{
	
	Stack<E> stack = new Stack<>();
	
	public void push(E obj) {
		stack.push(obj);
	}
	public E pop() {
		E obj = stack.pop();
		return obj;
	}

	public static void main(String[] args) {
		Generic<String> gs = new Generic<String>();
		gs.push("Hello");
		System.out.print(gs.pop() + " ");
		Generic<Integer> gs2 = new Generic<Integer>();
		gs2.push(44);
		System.out.println(gs.pop());
	

	}

}
