package MockInterviewPractice;

import java.util.Scanner;

public class SwapTwoNumbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the First Number : ");
		int n1 = sc.nextInt();
		System.out.println("Enter the Second Number : ");
		int n2 = sc.nextInt();
		System.out.println("Before swap : "+"n1 = "+n1+" n2 = "+n2);
		sc.close();
		int temp=n1;
		n1=n2;
		n2=temp;
		
		System.out.println("After swaap : "+" n1 = "+n1+" n2 = "+n2);
		
		
	
		
		

	}

}
