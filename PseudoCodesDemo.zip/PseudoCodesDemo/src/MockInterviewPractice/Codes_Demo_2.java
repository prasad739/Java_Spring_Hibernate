package MockInterviewPractice;

import java.util.Collections;
import java.util.List;

//class Foo{
//	String name="Foo";
//	void print() {
//		this.print(new Bar().name);
//	}
//	void print(String argument) {
//		System.out.println(argument);
//	}
//}
//class Bar extends Foo{
//	String name ="Bar";
//	void print() {
//		this.print(super.name);
//	}
//}



public class Codes_Demo_2 {

	public static void main(String[] args) {
//		Foo foo = new Bar();
//		foo.print();
//		Object[] array1 =  new Object[] {"John",30};
//		Object[] array2 =  new Object[] {new int[][] {}};
//		Object[] array3 =  new Object[1] {new Object()};
//		Object[] array4 =  new String[0];
//		Object[] array5 =  new Integer[][] {{}};

		
//		StringBuilder b1 = new StringBuilder(21);
//		StringBuilder b2 = new StringBuilder("Hello");
//		int a = b1.capacity();
//		int b = b2.capacity();
//		System.out.println(a==b);

		
//		System.out.println("start");
//		try {
//			System.out.println("try");
//			System.out.println(10/0);
//		}
//		catch(NullPointerException ex) {
//			System.out.println("catch");
//		}
//		finally {
//			System.out.println("finally");
//		}
//		System.out.println("end");
		
//		List<Integer> list = Collections.singletonList(3);
//		list.addAll(List.of(2,1));
//		Collections.sort(list);
//		System.out.println(list);

		//		int count =1;
//		while(count<=15) {
//			System.out.println(count % 2 ==1 ? "***" : "+++++");
//			++count;
//		}
		
		
		
	}

}
