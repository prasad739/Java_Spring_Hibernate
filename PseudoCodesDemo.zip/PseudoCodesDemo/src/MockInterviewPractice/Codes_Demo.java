package MockInterviewPractice;

class Father{
	public void vehicle() {
		System.out.println("Father a vehicle");
	}
}
class Son extends Father{
	public void vehicle() {
		System.out.println("Son  a vehicle");
	}
	
}

public class Codes_Demo {

//	{
//		System.out.println("DoSelect");
//	}
//	
//	static {
//		System.out.println("Static");
//	}
	public static void main(String[] args) {

//		String text;
//		if(text==null) {
//			text = "foo";
//		}
//		System.out.println(text);

//		String text ="hiheyhello";
//		int index=text.lastIndexOf("h",4);
//		System.out.println(index);

//		Set<Integer> set = new LinkedHashSet<>(Set.of(1,2));
//		set.removeIf(i->i%2==0);
//		System.out.println(set);

		// int x_y;

//		System.out.println("main");
		
		
		
//		int arr[] = new int[] {0,1,2,3,4,5,6,7,8,9};
//		int n=6;
//		n=arr[arr[n] /2];
//		System.out.println(arr[n] /2);
		
		Son john = new Son();
		john.vehicle();
		
		
		
		
		
		
		
		
		
		

	}

}
