package MockInterviewPractice;

public class Test implements Runnable{
	
	public void run() {
		System.out.printf("Welcome ");
		System.out.printf("To ");
	}
	public static void main(String[] args) {
		Test obj = new Test();
		Thread thread = new Thread(obj);
		thread.start();
		System.out.printf("Java ");
		try {
			thread.join();
		}
		catch(InterruptedException ex) {
			ex.printStackTrace();
		}
		System.out.println("Prog");
	}
	

}
