package MockInterviewPractice;

import java.io.FileNotFoundException;
import java.io.IOException;




public class Sample {
	
		


	public static void main(String[] args) throws Exception {

		try {
			MyFun(-15);
			MyFun(-2);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		MyFun(24);
	}
	public static void MyFun(int i) throws Exception{
	if(i<0) {
		FileNotFoundException data = new FileNotFoundException(""+i);
		throw data;
	}else if(i>10) {
		throw new IOException("Not supported");
	}
	
	
	
	
	
	

}
	
}
