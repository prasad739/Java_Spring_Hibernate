package com.numberprograms;

import java.util.Scanner;

public class NthPrime {
	public static boolean isPrime(int num) {

		boolean flag = true;

		if (num <= 1) {
			flag = false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the Number You Want to check: ");
		int position = sc.nextInt();

		int count = 0, i = 2;

		while (i != 0) {

			if (NthPrime.isPrime(i)) {
				count++;
			}
			if (count == position) {
				System.out.println(i);
				break;
			}
			i++;
		}
		

	}

}
