package com.numberprograms;

import java.util.Scanner;

public class PrimeRange {

	public static boolean isPrime(int num) {

		boolean flag = true;

		if (num <= 1) {
			flag = false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the lower limit: ");
		int lowerLimit = sc.nextInt();

		System.out.println("Enter the Upper limit: ");
		int upperLimit = sc.nextInt();

		for (int i = lowerLimit; i <= upperLimit; i++) {
			if (PrimeRange.isPrime(i)) {
				System.out.print(i + " ");
			}

		}
	}

}
