package com.springcore.reftypes;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentTest {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext
				("com/springcore/reftypes/refConfig.xml");
		
		Student student = (Student)context.getBean("student");
		
		System.out.println("Student Id: "+student.getStudentId());
		System.out.println("Student Name: "+student.getStudentName());
		System.out.println("Student Address: "+student.getAddress());
		
		context.close();
		

	}

}
