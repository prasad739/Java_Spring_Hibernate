package com.springcore.list;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCollege {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"com/springcore/list/listConfig.xml");

		College clg = (College) context.getBean("college");

		System.out.println("College Code: " + clg.getClgCode());
		System.out.println("College Name: " + clg.getClgName());
		System.out.println("Departments: " + clg.getDepartments().getClass());

		context.close();

	}

}
