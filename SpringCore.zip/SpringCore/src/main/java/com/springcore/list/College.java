package com.springcore.list;

import java.util.List;

public class College {

	private int clgCode;
	private String clgName;
	private List<String> departments;

	public College() {
		super();
	}

	public College(int clgCode, String clgName, List<String> departments) {
		super();
		this.clgCode = clgCode;
		this.clgName = clgName;
		this.departments = departments;
	}

	public int getClgCode() {
		return clgCode;
	}

	public void setClgCode(int clgCode) {
		this.clgCode = clgCode;
	}

	public String getClgName() {
		return clgName;
	}

	public void setClgName(String clgName) {
		this.clgName = clgName;
	}

	public List<String> getDepartments() {
		return departments;
	}

	public void setDepartments(List<String> departments) {
		this.departments = departments;
	}

}
