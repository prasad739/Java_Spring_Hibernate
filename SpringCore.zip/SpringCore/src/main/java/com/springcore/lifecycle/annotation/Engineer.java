package com.springcore.lifecycle.annotation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Engineer {

	private String name;

	public Engineer() {
		System.out.println("Engineer Constructor Called....");
	}

	@PostConstruct
	public void show() {

		System.out.println("Init method called.........");

	}

	@PreDestroy
	public void display() {

		System.out.println("destroy method called.....");

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("Setter method called....");
		this.name = name;
	}

}
