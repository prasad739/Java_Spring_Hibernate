package com.springcore.lifecycle.annotation;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEngineer {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"com/springcore/lifecycle/annotation/config.xml");

		context.close();

	}

}
