package com.springcore.lifecycle.interfaces;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEngineer {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(
				"com/springcore/lifecycle/interfaces/config.xml");

		context.close();

	}

}
