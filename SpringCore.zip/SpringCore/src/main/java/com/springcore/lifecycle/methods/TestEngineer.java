package com.springcore.lifecycle.methods;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEngineer {
	
	public static void main(String[] args) {
		
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext
				("com/springcore/lifecycle/methods/Config.xml");
		
		context.close();
	}

}
