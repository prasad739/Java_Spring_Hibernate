package com.springcore.lifecycle.interfaces;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Engineer implements InitializingBean, DisposableBean {

	public void destroy() throws Exception {

		System.out.println("destroy method called.....");

	}

	public void afterPropertiesSet() throws Exception {

		System.out.println("Init method called.........");

	}

}
