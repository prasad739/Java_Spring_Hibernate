package com.springcore.lifecycle.methods;

public class Engineer {

	public void display() {
		System.out.println("init-method called...");

	}

	public void show() {
		System.out.println("destroy method called....");
	}

}
