package com.springcore.set;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDepartment {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new 
				ClassPathXmlApplicationContext("com/springcore/set/setConfig.xml");

		Department dept = (Department) context.getBean("department");

		System.out.println(dept.getDepartmentId());
		System.out.println(dept.getSubjects());

		context.close();

	}

}
