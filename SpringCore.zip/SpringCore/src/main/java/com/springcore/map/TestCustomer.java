package com.springcore.map;

import java.util.Set;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCustomer {

	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/map/mapConfig.xml");

		Customer customer = (Customer) context.getBean("customer");

		System.out.println("Customer Id: " + customer.getCustomerId());

		Set<Integer> set = customer.getCarModels().keySet();

		System.out.println("Car Models");
		for (Integer i : set) {

			System.out.println(i + " " + customer.getCarModels().get(i));
		}

		context.close();

	}

}
