package com.springcore.map;

import java.util.Map;

public class Customer {

	private int customerId;
	private Map<Integer, String> carModels;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Map<Integer, String> getCarModels() {
		return carModels;
	}

	public void setCarModels(Map<Integer, String> carModels) {
		this.carModels = carModels;
	}

}
