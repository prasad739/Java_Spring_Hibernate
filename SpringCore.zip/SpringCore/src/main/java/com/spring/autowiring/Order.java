package com.spring.autowiring;

public class Order {

	private String orderId;
	private String orderDate;
	private double totalAmount;

	public Order() {
		super();
	}

	public Order(String orderId, String orderDate, double totalAmount) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.totalAmount = totalAmount;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + getOrderDate() + ", totalAmount=" + totalAmount + "]";
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

}
