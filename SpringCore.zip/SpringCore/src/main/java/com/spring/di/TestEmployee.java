package com.spring.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext
				("com/spring/di/config.xml");

		Employee emp = (Employee) ctx.getBean("emp");
		
		Employee emp2 = (Employee) ctx.getBean("emp");
		
		System.out.println(emp.hashCode());
		System.out.println(emp2.hashCode());
		
		

		System.out.println(emp.getId());
		System.out.println(emp.getName());
		
		

	}
}
