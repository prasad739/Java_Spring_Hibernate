import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException {

		File file = new File("./demo.txt");
		
		System.out.println(file.createNewFile());

	}

}
