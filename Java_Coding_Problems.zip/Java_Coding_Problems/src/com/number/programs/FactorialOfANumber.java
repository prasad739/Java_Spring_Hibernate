package com.number.programs;

import java.util.Scanner;

public class FactorialOfANumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number: ");
		int num = sc.nextInt();
		sc.close();
		
		if (num == 0 || num == 1) {
			System.out.println(num + "'s factorial is " + 1);
			return;
		}
		
		int ans = 1;

		for (int i = num; i > 0; i--) {
			ans = ans * i;
		}
		System.out.println(num + "'s factorial is " + ans);

	}

}
