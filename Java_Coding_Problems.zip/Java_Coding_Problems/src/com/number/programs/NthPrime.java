package com.number.programs;

import java.util.Scanner;

public class NthPrime {

	public static boolean isPrime(int num) {

		boolean flag = true;

		if (num <= 1) {
			flag = false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
			}
		}
		return flag;
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the required position of a number: ");
		int requiredPosition = sc.nextInt();
		sc.close();

		int count = 0;

//		for (int i = 2;; i++) {
//
//			if (NthPrime.isPrime(i)) {
//				count++;
//			}
//
//			if (count == requiredPosition) {
//				System.out.println(i);
//				return;
//			}
//
//		}

		int i = 2;

		while (true) {
			if (NthPrime.isPrime(i)) {
				count++;
			}

			if (count == requiredPosition) {
				System.out.println(i);
				return;
			}
			
			i++;

		}

	}
}
