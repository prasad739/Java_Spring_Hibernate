package com.number.programs;

import java.util.Scanner;

public class PerfectSquareCheck {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number you want to check: ");
		int num = sc.nextInt();
		sc.close();

		int count = 0;
		for (int i = 1; i < num/2; i++) {

			if (i * i == num) {
				System.out.println(i);
				count++;
			}
		}
		if (count == 1) {
			System.out.println("It is a perfect number ");
		} else {
			System.out.println("It is not a perfect number ");
		}

	}

}
