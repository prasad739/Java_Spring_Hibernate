package com.number.programs;

import java.util.Scanner;

public class PrimeRange {

	public static boolean isPrime(int num) {

		boolean flag = true;

		if (num <= 1) {
			flag = false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
			}
		}
		return flag;
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the lower limit: ");
		int num1 = sc.nextInt();
		
		System.out.println("Enter the upper limit: ");
		int num2 = sc.nextInt();
		sc.close();

		
		for (int i = num1; i <= num2; i++) {
			
			if (PrimeRange.isPrime(i)) {
				System.out.print(i + " ");
			}

		}
		

	}
}
