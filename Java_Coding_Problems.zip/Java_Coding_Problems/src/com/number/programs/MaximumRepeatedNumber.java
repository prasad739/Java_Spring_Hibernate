package com.number.programs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class MaximumRepeatedNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the array size: ");
		int arrSize = sc.nextInt();

		int arr[] = new int[arrSize];

		System.out.println("Enter the array elements: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();

		Map<Integer, Integer> map = new LinkedHashMap<>();

		for (Integer i : arr) {

			if (map.containsKey(i)) {
				map.put(i, map.get(i) + 1);
			} else {
				map.put(i, 1);
			}
		}

		int maxRepeatedNumber=0, frequeny = 0;
		for (Integer i : map.keySet()) {

			
			if (map.get(i) > frequeny) {
				frequeny = map.get(i);
				maxRepeatedNumber = i;
			}

		}
		
		System.out.println(maxRepeatedNumber+" = "+frequeny);

	}

}
