package com.number.programs;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number ");
		long num = sc.nextLong();
		sc.close();

		long rem, sum = 0, rev = num;

		while (num != 0) {
			rem = (num % 10);
			sum = sum * 10 + rem;
			num = num / 10;
		}
		if (rev == sum) {
			System.out.println("It is a palindrome");
		} else {
			System.out.println("Not a palindrome");
		}

	}

}
