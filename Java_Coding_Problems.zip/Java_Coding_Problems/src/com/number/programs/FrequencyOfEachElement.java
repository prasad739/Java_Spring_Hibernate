package com.number.programs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class FrequencyOfEachElement {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the array size: ");
		int arrSize = sc.nextInt();

		int arr[] = new int[arrSize];

		System.out.println("Enter the array elements: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();

		// To keep track of visited elements
		boolean visited[] = new boolean[arrSize];

		System.out.println("Frequency of each element:");
		for (int i = 0; i < arr.length; i++) {
			if (visited[i]) {
				continue; // Skip already counted elements
			}

			int count = 1; // Initialize count for the current element
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
					visited[j] = true; // Mark duplicate element as visited
				}
			}

			System.out.println(arr[i] + " occurs " + count + " times");

		}

		Map<Integer, Integer> map = new LinkedHashMap<>();

		for (Integer num : arr) {

			if (map.containsKey(num)) {
				map.put(num, map.get(num) + 1);
			}

			else {
				map.put(num, 1);
			}
		}

		for (Integer i : map.keySet()) {
			System.out.println(i + "occurs " + map.get(i) + " times ");
		}

	}
}
