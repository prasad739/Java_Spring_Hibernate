package com.number.programs;

import java.util.Scanner;

public class PrimeNumberCheck {

	public static boolean isPrime(int num) {

		boolean flag = true;

		if (num <= 1) {
			flag = false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				flag = false;
			}
		}
		return flag;
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number you want to check: ");
		int num = sc.nextInt();
		sc.close();

		if (PrimeNumberCheck.isPrime(num)) {
			System.out.println("It is a prime number: ");
		} else {
			System.out.println("Not a prime number: ");
		}

	}

}
