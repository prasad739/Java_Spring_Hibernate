package com.number.programs;

import java.util.Scanner;

public class NthFibanocci {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the position (N) for the Fibonacci number: ");
		int num = sc.nextInt();
		sc.close();

		if (num < 0) {
			System.out.println("Enter a positive number.");
		} 
		else if (num == 0) {
			System.out.println("The 0th Fibonacci number is: 0");
		}
		else if (num == 1) {
			System.out.println("The 1st Fibonacci number is: 1");
		}
		else {
			int a = 0, b = 1, c = 0;
			for (int i = 2; i < num; i++) {
				c = a + b;
				a = b;
				b = c;
			}
			System.out.println("The " + num + "th Fibonacci number is: " + c);
		}

	}

}
