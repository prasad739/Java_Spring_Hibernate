package com.number.programs;

import java.util.Scanner;

public class FibanocciSeries {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the Number: ");
		int num = sc.nextInt();
		int a = 0, b = 1, c;
		System.out.print(a + " " + b);
		sc.close();

		for (int i = 2; i < num; i++) {
			c = a + b;
			System.out.print(" " + c);
			a = b;
			b = c;
		}

	}

}
