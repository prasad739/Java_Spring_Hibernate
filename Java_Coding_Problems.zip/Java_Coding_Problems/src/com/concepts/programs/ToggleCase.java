package com.concepts.programs;

public class ToggleCase {

	public static void main(String[] args) {

		String str = "LaLiTa";

//		for (int i = 0; i < str.length(); i++) {
//			char ch = str.charAt(i);
//
//			if (Character.isLowerCase(ch)) {
//				ch = Character.toUpperCase(ch);
//			} 
//			
//			else if (Character.isUpperCase(ch)) {
//				ch = Character.toLowerCase(ch);
//			}
//			System.out.print(ch + " ");
//
//		}

		for (int i = 0; i < str.length(); i++) {

			char ch = str.charAt(i);
			
			if (ch >= 'a' && ch <= 'z') {
				
				  ch = (char) (ch-32);

			}

		}

	}

}
