package com.concepts.programs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Student implements Comparable<Student> {

	private String name;
	private int age;

	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int compareTo(Student s) {

		return this.age - s.age;
	}

}

public class ComparableDemo {

	public static void main(String[] args) {

		List<Student> list = new ArrayList<>(
				Arrays.asList(new Student("Prasad", 67), new Student("Swetha", 23), new Student("Pavani", 45)));

		list.add(new Student("Lalita", 34));

		Collections.sort(list);

		for (Student s : list) {
			System.out.println(s.getName() + " " + s.getAge());
		}

	}

}
