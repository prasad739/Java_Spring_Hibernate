package com.concepts.programs;

abstract class Shape {

	String shapeName;

	// Default constructor
	public Shape() {
		super();
	}

	// parameterized constructor
	public Shape(String shapeName) {
		this.shapeName = shapeName;
	}

	// abstract method
	abstract double calculateArea(double length, double breadth);

	// Normal method
	public double calculatePerimeter(double length, double breadth) {
		return 2 * (length + breadth);
	}

	// static method
	static void shapeInformation() {
		System.out.println("Shape have a Rectangle and Square");
	}

}

class Rectangle extends Shape {

	Rectangle() {
		super("Reactangle");
	}

	@Override
	public double calculateArea(double length, double breadth) {

		return length * breadth;
	}
}

public class AbstractionDemo {

	public static void main(String[] args) {

		Shape shape = new Rectangle();
		System.out.println(shape.shapeName);
		System.out.println(shape.calculateArea(3, 5));
		System.out.println(shape.calculatePerimeter(3, 5));

	}

}
