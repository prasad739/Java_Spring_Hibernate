package com.concepts.programs;

public class StringsDemo {

	public static void main(String[] args) {

		String str = "Laxmi";
		System.out.println(str.hashCode());
		
		str = str.concat(" Prasad");
		System.out.println(str.hashCode());

		System.out.println(str);

	}

}
