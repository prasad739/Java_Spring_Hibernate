package com.concepts.programs;

class Parent {

	String name;

	Parent() {
		System.out.println("Default-----------Parent");
	}

	Parent(String name) {
		this.name = name;
	}

}

class Child extends Parent {

	int age;

//	Child() {
//		//super();
//		System.out.println("Default------------Child");
//	}

//	Child(int age) {
//		this.age = age;
//	}

}

public class SuperTestDemo {

	public static void main(String[] args) {

		Child child = new Child();

	}
}
