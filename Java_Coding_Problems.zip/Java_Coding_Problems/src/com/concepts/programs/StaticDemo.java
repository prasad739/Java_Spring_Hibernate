package com.concepts.programs;

public class StaticDemo {

	// static block
	static {
		System.out.println("static block is called.....");
	}

	// static data member
	static String name = "Static string";

	// static method
	static int add(int num1, int num2) {
		return num1 + num2;
	}

	public static void main(String[] args) {

		System.out.println(StaticDemo.name);
		System.out.println(StaticDemo.add(23, 54));

	}
}
