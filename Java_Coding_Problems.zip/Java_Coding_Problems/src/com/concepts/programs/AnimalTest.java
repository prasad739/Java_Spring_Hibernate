package com.concepts.programs;

class Animal {

	String name = "Tiger";
	int age;

	void show() {
		System.out.println("Parent method is called.....");
	}

	Animal() {
		System.out.println("Parent class constructor is called......");
	}

}

class Lion extends Animal {
	String name = "Lion";

	void show() {
		super.show();
		System.out.println(this.name + " " + super.name);
	}

	Lion() {
		System.out.println("Child constructor is called....");
	}

}

public class AnimalTest {

	public static void main(String[] args) {

		Lion lion = new Lion();
		lion.show();

	}

}
