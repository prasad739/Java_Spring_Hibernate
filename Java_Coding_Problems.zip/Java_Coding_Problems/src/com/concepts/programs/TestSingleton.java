package com.concepts.programs;

class SingletonDemo {

	private static SingletonDemo singletonDemo = null;

	private String name;

	// constructor
	private SingletonDemo() {
	}

	// getter and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// object creation 
	public static  SingletonDemo getSingletonDemo() {

		if (singletonDemo == null) {
			singletonDemo = new SingletonDemo();
		}
		return singletonDemo;
	}

}

public class TestSingleton {

	public static void main(String[] args) {
		SingletonDemo sd = SingletonDemo.getSingletonDemo();
		sd.setName("Prasad");
		System.out.println(sd.getName());
	}

}
