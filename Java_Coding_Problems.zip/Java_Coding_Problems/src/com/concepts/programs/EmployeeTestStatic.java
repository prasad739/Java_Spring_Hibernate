package com.concepts.programs;

class Employee {

	private int employeeId;
	private String name;
	private int age;
	static String companyName = "Capgemeini";
	static int counter = 0;

	// parameterized constructor
	public Employee(String name, int age) {
		this.setName(name);
		this.setAge(age);
		this.employeeId = incrementEmployeeId();

	}

	// getters and setters
	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = counter++;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	// method to print the employee details
	public void employeeDetails() {

		System.out.println(this.employeeId + " " + this.name + " " + 
		this.age+" "+companyName);
	}

	// Static method to generate unique IDs
	public static int incrementEmployeeId() {
		return counter++;
	}

}

public class EmployeeTestStatic {

	public static void main(String[] args) {

		Employee emp = new Employee("Prasad", 23);
		emp.employeeDetails();

		Employee emp2 = new Employee("Swetha", 24);
		emp2.employeeDetails();

		
		Employee emp3 = new Employee("Priya", 46);
		emp3.employeeDetails();
	}
}
