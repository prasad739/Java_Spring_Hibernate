package com.concepts.programs;

class Person implements Cloneable {
	String name;
	int age;

	// Parameterized constructor
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	// Clone method
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}

public class ObjectCloningDemo {

	public static void main(String[] args) throws CloneNotSupportedException {

		Person p1 = new Person("Prasad", 22);

		Person p2 = (Person) p1.clone();

		System.out.println(p1.hashCode() + " " + p2.hashCode());

	}

}
