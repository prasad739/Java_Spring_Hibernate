package com.concepts.programs;

class Fruits {

	String name;
	double price;

//	public Fruits(String name, double price) {
//		this.name = name;
//		this.price = price;
//	}

	public Fruits() {

	}

	public void show() {
		System.out.println("show method called......");
	}

	public void getFruits(Fruits fruits) {
		System.out.println(fruits.name + " = " + (fruits.price + 10));
	}

	public void display() {
		name = "Water Melon";
		price = 95.0;
		getFruits(this);

		this.show();
	}

}

public class FruitsTest {

	public static void main(String[] args) {

		Fruits fr = new Fruits();
		fr.display();

	}
}
