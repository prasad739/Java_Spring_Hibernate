package com.concepts.programs;

class Engineer {

	private String name;
	private int age;

	public Engineer() {
		this("Prasad", 24);
		System.out.println("Default constructor");
	}

	public Engineer(String name, int age) {
		// refer the current class instance variable
		this.name = name;
		this.age = age;
		System.out.println("Parameterized constructor");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}

public class EngineerDemo {

	public static void main(String[] args) {

		// Engineer eng = new Engineer("Swetha", 23);
		// eng.display();

		Engineer eng = new Engineer();
		System.out.println(eng.getName() + " " + eng.getAge());

	}

}
