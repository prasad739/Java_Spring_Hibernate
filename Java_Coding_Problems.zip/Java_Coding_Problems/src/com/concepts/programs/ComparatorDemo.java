package com.concepts.programs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Doctor {
	private String name;
	private int age;
	private double salary;

	public Doctor() {
		super();
	}

	public Doctor(String name, int age, double salary) {
		super();
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}

public class ComparatorDemo {

	public static void main(String[] args) {

		List<Doctor> list = new ArrayList<>(Arrays.asList(new Doctor("Prasad", 22, 37800),
				new Doctor("Swetha", 35, 29500), 
				new Doctor("Lochana", 19, 56000), 
				new Doctor("Lalita", 34, 76000)));

		Comparator<Doctor> cmp1 = new Comparator<Doctor>() {

			public int compare(Doctor d1, Doctor d2) {
				if (d1.getAge() > d2.getAge()) {
					return 1;
				} else if (d1.getAge() < d2.getAge()) {
					return -1;
				} else {
					return 0;
				}

			}
		};

		Comparator<Doctor> cmp2 = new Comparator<>() {

			public int compare(Doctor d1, Doctor d2) {

				if (d1.getName().compareToIgnoreCase(d2.getName()) > 0) {
					return 1;
				}

				else if (d1.getName().compareToIgnoreCase(d2.getName()) < 0) {
					return -1;
				} else {
					return 0;
				}
			}
		};

		Collections.sort(list, cmp1);

		for (Doctor d : list) {
			System.out.println(d.getName() + " " + d.getAge() + " " + d.getSalary());
		}

		Collections.sort(list, cmp2);

		System.out.println("==========SOrting based on name==========");

		for (Doctor d : list) {
			System.out.println(d.getName() + " " + d.getAge() + " " + d.getSalary());
		}

		System.out.println("==========Highest Salaried Object===========");
		
		
		
		for (Doctor d : list) {
			System.out.println(d.getName() + " " + d.getAge() + " " + d.getSalary());
		}
		double max = list.get(0).getSalary();
		System.out.println(max);
		Doctor maxSalariedDoctor=null;
		
		for (Doctor d : list) {
			if (max > d.getSalary()) {
				max = d.getSalary();
				maxSalariedDoctor = d;
			}
		}
		System.out.println(maxSalariedDoctor.getName()+" "+maxSalariedDoctor.getAge()+" "+
		maxSalariedDoctor.getSalary());

	}
}
