package com.concepts.programs;

class Employee2 implements Cloneable{
	String name;

	Employee2() {

	}

	Employee2(String name) {
		this.name = name;

	}

	@Override
	public String toString() {
		return "Employee2 [name=" + name + "]";
	}
	
	protected Object clone() throws CloneNotSupportedException{
		return super.clone();
	}

}

public class ObjectCopyDemo {

	public static void main(String[] args) throws CloneNotSupportedException{

		Employee2 emp = new Employee2("Akhil");
		
		Employee2 emp2 = (Employee2 ) emp.clone();
		
		emp2.name="Lalita";
		
		System.out.println(emp);
		System.out.println(emp2);



	}

}
