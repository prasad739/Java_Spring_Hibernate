package com.sortingtechniques;

public class BubbleSortDemo {

	public static void main(String[] args) {

		int[] arr = { 78, 23, 1, 6, 56 };

		int temp;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length - 1; j++) {
				// swapping elements
				if (arr[j] > arr[j + 1]) {
					temp = arr[j]; // temp = a;
					arr[j] = arr[j + 1]; // a =b
					arr[j + 1] = temp; // b= temp

				}

			}
		}

		for (int i : arr) {
			System.out.print(i + " ");
		}

	}

}
