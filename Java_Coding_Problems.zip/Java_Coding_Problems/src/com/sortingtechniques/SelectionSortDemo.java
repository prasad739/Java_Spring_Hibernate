package com.sortingtechniques;

public class SelectionSortDemo {

	public static void main(String[] args) {

		int[] arr = { 78, 23, 1, 6, 56 };

		int min = arr[0], temp;

		for (int i = 1; i < arr.length; i++) {

			if (min < arr[i]) {
				min = arr[i];
			}

		}

		for (int i : arr) {
			System.out.print(i + " ");
		}

	}

}
