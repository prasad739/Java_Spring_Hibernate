package com.string.programs;

public class String_Reversal {

	public static void main(String[] args) {

		String str = "Virat Kohli";

		for (int i = str.length() - 1; i >= 0; i--) {
			
			System.out.print(str.charAt(i) + " ");
		
		}
	}

}
