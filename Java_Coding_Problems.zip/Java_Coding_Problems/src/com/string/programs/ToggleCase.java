package com.string.programs;

public class ToggleCase {

	public static void main(String[] args) {

		String str = "eLePhAnT";

		char ch = 0;

		for (int i = 0; i < str.length(); i++) {

			ch = str.charAt(i);

			if (Character.isUpperCase(ch)) {
				ch = Character.toLowerCase(ch);
			}

			else if (Character.isLowerCase(ch)) {
				ch = Character.toUpperCase(ch);

			}
			System.out.print(ch + " ");

		}

	}

}
