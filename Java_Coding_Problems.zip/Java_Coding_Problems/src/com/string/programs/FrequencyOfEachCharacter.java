package com.string.programs;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class FrequencyOfEachCharacter {

	public static void main(String[] args) {

		String str = "laxmi prasad";

		Map<Character, Integer> map = new LinkedHashMap<>();

		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) != ' ') {
				if (map.containsKey(str.charAt(i))) {
					map.put(str.charAt(i), map.get(str.charAt(i)) + 1);

				} else {
					map.put(str.charAt(i), 1);
				}
			}
		}

		Set<Character> set = map.keySet();

		for (Character ch : set) {
			System.out.println(ch + "= " + map.get(ch));
		}

	}

}
