package com.string.programs;

public class StringsDemo {

	public static void main(String[] args) {
		
		String str ="prasad";
		 
		

	}
}
