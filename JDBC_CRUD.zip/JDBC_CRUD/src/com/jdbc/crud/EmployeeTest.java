package com.jdbc.crud;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

public class EmployeeTest {

	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		Employee emp = new Employee(75, "Prasad", 37, 37500);
		
		EmployeeService es = new EmployeeService();
		
		System.out.println(es.addEmployee(emp));
		
		//System.out.println(es.updateEmployee(emp));
		
		//System.out.println(es.getEmployee(75));
		
		//System.out.println(es.getAllEmployees());
		
		//System.out.println(es.createTable("STUDENT"));
				

	}

}
