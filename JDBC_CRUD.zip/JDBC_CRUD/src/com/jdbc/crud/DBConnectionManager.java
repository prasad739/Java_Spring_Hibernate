package com.jdbc.crud;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnectionManager {

	private static Connection con = null;

	private static Properties props ;

	public static Connection getConnection() throws IOException, FileNotFoundException, SQLException, ClassNotFoundException {

		File file = new File("application.properties");

		if (!file.exists())
			file.createNewFile();

		FileInputStream fis = new FileInputStream(file);
		
		props = new Properties();

		props.load(fis);

		String driverName = props.getProperty("driverName");

		Class.forName(driverName);

		String url = props.getProperty("url");
		String username = props.getProperty("username");
		String password = props.getProperty("password");

		con =  DriverManager.getConnection(url, username, password);
		
		return con;

	}

	public static void main(String[] args) throws FileNotFoundException, IOException, SQLException, ClassNotFoundException {

		System.out.println(DBConnectionManager.getConnection());
	}

}
