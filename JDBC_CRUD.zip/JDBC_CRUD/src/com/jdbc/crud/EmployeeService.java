package com.jdbc.crud;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class EmployeeService {

	Connection con = null;

	PreparedStatement ps;
	int row;
	ResultSet resultSet;

	public String createTable(String tableName)
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		String query = "CREATE TABLE " + tableName + " ( name varchar(50), id int)";
		Statement st = con.createStatement();
		row = st.executeUpdate(query);
		System.out.println(row);

		return tableName;

	}

	public Employee addEmployee(Employee employee)
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		String insert = "INSERT INTO Employee VALUES(?,?,?,?)";

		ps = con.prepareStatement(insert);

		ps.setInt(1, employee.getEmpId());
		ps.setString(2, employee.getEmpName());
		ps.setInt(3, employee.getAge());
		ps.setDouble(4, employee.getEmpSalary());

		row = ps.executeUpdate();

		if (row == 1)
			return employee;
		else
			return null;

	}

	public Employee updateEmployee(Employee emp)
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		String update = "UPDATE EMPLOYEE SET empAge=? WHERE empName=?";

		ps = con.prepareStatement(update);

		ps.setInt(1, emp.getAge());
		ps.setString(2, emp.getEmpName());

		row = ps.executeUpdate();

		if (row > 0)
			return emp;
		else
			return null;

	}

	public String deleteEmployee(int employeeId)
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		String delete = "DELETE FROM EMPLOYEE WHERE empId=?";

		ps = con.prepareStatement(delete);

		ps.setInt(1, employeeId);

		row = ps.executeUpdate();

		if (row > 0)
			return "employees successfully deleted";
		else
			return null;

	}

	public Employee getEmployee(int employeeId)
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		String getEmployee = "SELECT * FROM EMPLOYEE WHERE empId=?";

		ps = con.prepareStatement(getEmployee);

		ps.setInt(1, employeeId);

		resultSet = ps.executeQuery();

		Employee emp = null;
		if (resultSet.next()) {

			emp = new Employee();
			emp.setEmpId(resultSet.getInt(1));
			emp.setEmpName(resultSet.getString(2));
			emp.setAge(resultSet.getInt(3));
			emp.setEmpSalary(resultSet.getDouble(4));
		}
		return emp;

	}

	public List<Employee> getAllEmployees()
			throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {

		con = DBConnectionManager.getConnection();

		List<Employee> list = new LinkedList<>();

		String getEmployee = "SELECT * FROM EMPLOYEE";

		ps = con.prepareStatement(getEmployee);

		resultSet = ps.executeQuery();

		Employee emp = null;
		while (resultSet.next()) {

			emp = new Employee();
			emp.setEmpId(resultSet.getInt(1));
			emp.setEmpName(resultSet.getString(2));
			emp.setAge(resultSet.getInt(3));
			emp.setEmpSalary(resultSet.getDouble(4));
			list.add(emp);
		}

		return list;

	}

}
