package com.jdbc.crud;

public class Employee {
	
	private int empId;
	private String empName;
	private int age;
	private double empSalary;
	
	public Employee() {
		super();
	}

	public Employee(int empId, String empName, int age, double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.age = age;
		this.empSalary = empSalary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", age=" + age + ", empSalary=" + empSalary + "]";
	}
	
	
	
	

}
