package com.spring.orm.hibernate.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.hibernate.Service.ProductService;
import com.spring.orm.hibernate.entity.Product;

public class ProductTest {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");

		ProductService ps = (ProductService) context.getBean("productService");

		Product product = new Product();

		product.setName("OnePlus");
		product.setDescription("One Plus Smart");
		product.setPrice(45000);

		System.out.println(ps.addProduct(product));

	}

}