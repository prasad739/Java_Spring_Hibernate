package com.spring.orm.hibernate.dao;

import java.util.List;

import com.spring.orm.hibernate.entity.Product;

public interface IProductDao {

	Product addProduct(Product product);

	Product updateProduct(Product product);

	String deleteProductByProductId(Long productId);

	Product getProductByProductProductId(Long productId);

	List<Product> getAllProducts();

}
