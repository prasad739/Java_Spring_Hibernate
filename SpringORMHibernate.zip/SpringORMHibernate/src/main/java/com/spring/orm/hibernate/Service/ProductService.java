package com.spring.orm.hibernate.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.spring.orm.hibernate.dao.IProductDao;
import com.spring.orm.hibernate.entity.Product;

public class ProductService implements IProductDao {

	@Autowired
	HibernateTemplate hibernateTemplate;

	public Product addProduct(Product product) {

		hibernateTemplate.save(product);

		return product;
	}

	public Product updateProduct(Product product) {
		return null;
	}

	public String deleteProductByProductId(Long productId) {
		return null;
	}

	public Product getProductByProductProductId(Long productId) {
		return null;
	}

	public List<Product> getAllProducts() {
		return null;
	}

}
